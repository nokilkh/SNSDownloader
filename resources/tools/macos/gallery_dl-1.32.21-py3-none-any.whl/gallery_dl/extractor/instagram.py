# -*- coding: utf-8 -*-

# Copyright 2018-2020 Leonardo Taccari
# Copyright 2018-2026 Mike Fährmann
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 as
# published by the Free Software Foundation.

"""Extractors for https://www.instagram.com/"""

from .common import Extractor, Message, Dispatch
from .. import text, util
import itertools

BASE_PATTERN = r"(?:https?://)?(?:www\.)?instagram\.com"
USER_PATTERN = BASE_PATTERN + r"/(?!(?:p|tv|reel|explore|stories)/)([^/?#]+)"

QUERIES = {
    "PolarisProfilePostsTabContentQuery_connection" : "28544666141895803",
    "PolarisProfileReelsTabContentQuery_connection" : "29285972954340351",
    "PolarisProfileTaggedTabContentQuery_connection": "28474042942277898",
    "PolarisProfileRepostsTabContentRefetchQuery"   : "39686700687609779",
    "PolarisProfileStoryHighlightsTrayContentQuery" : "26970053832668570",
    "PolarisStoriesV3ReelPageGalleryQuery"          : "29306733562261201",
    "PolarisStoriesV3TrayContainerQuery"            : "38657722893875056",
    "PolarisProfilePageContentQuery"                : "28717443601247930",
}


class InstagramExtractor(Extractor):
    """Base class for instagram extractors"""
    category = "instagram"
    directory_fmt = ("{category}", "{username}")
    filename_fmt = "{sidecar_media_id:?/_/}{media_id}.{extension}"
    archive_fmt = "{media_id}"
    root = "https://www.instagram.com"
    cookies_domain = ".instagram.com"
    cookies_names = ("sessionid",)
    browser = "chrome"
    useragent = util.USERAGENT_CHROME
    request_interval = (6.0, 12.0)

    def __init__(self, match):
        Extractor.__init__(self, match)
        self.item = match[1]

    def _init(self):
        self.www_claim = "0"
        self.csrf_token = util.generate_token()
        self._find_tags = text.re(r"#\w+").findall
        self._logged_in = True
        self._cursor = None
        self._user = None

        self.cookies.set(
            "csrftoken", self.csrf_token, domain=self.cookies_domain)

        if not (wd := self.config("wd", False)):
            self.cookies.set("wd", None, domain=self.cookies_domain)
        elif wd.__class__ is str:
            self.cookies.set("wd", wd, domain=self.cookies_domain)

        self.api = InstagramAPI(self)

        self._highlight_covers = \
            True if self.config("covers") else False
        self._static_video = \
            True if self.config("static-videos", True) else False
        self._warn_video = \
            True if self.config("warn-videos", True) else False
        self._warn_image = (
            9 if not (wi := self.config("warn-images", True)) else
            1 if wi in {"all", "both"} else
            0)

    def items(self):
        self.login()
        data = self.metadata()

        if videos := self.config("videos", True):
            self.videos_dash = videos_dash = (videos != "merged")
        else:
            self.videos_dash = False

        if audio := self.config("audio", False):
            audio_dash = (audio != "merged")
        else:
            audio_dash = False

        if previews := self.config("previews", False):
            if previews.__class__ is str:
                previews = previews.split(",")
            elif previews.__class__ is not list:
                previews = {"video", "audio"}
            previews_video = ("video" in previews)
            previews_audio = ("audio" in previews)
        else:
            previews_video = previews_audio = False
        del previews

        pinned = self.config("pinned", True)
        max_posts = self.config("max-posts")
        order = self.config("order-files")
        reverse = order[0] in {"r", "d"} if order else False
        videos_headers = {"User-Agent": "Mozilla/5.0"}

        posts = self.posts()
        if max_posts:
            posts = itertools.islice(posts, max_posts)

        for post in posts:
            post = self._parse_post(post)

            if not pinned and post.get("pinned"):
                self.log.debug("%s: Skipping pinned post", post.get("post_id"))
                continue

            if self._user:
                post["user"] = self._user
            post.update(data)
            files = post.pop("_files")

            post["count"] = len(files)
            yield Message.Directory, "", post

            if reverse:
                files.reverse()

            for file in files:
                file = {**post, **file}

                if url := file.get("audio_url"):
                    if audio:
                        file["_http_headers"] = videos_headers
                        text.nameext_from_url(url, file)
                        if audio_dash and "_ytdl_manifest_data" in file:
                            file["_fallback"] = (url,)
                            file["_ytdl_manifest"] = "dash"
                            url = f"ytdl:{post['post_url']}{file['num']}.m4a"
                        yield Message.Url, url, file
                    if previews_audio and file.get("display_url"):
                        file["media_id"] = f"{file['media_id']}p"
                    else:
                        continue
                elif url := file.get("video_url"):
                    if videos:
                        file["_http_headers"] = videos_headers
                        text.nameext_from_url(url, file)
                        if videos_dash and "_ytdl_manifest_data" in file:
                            file["_fallback"] = (url,)
                            file["_ytdl_manifest"] = "dash"
                            url = f"ytdl:{post['post_url']}{file['num']}.mp4"
                        yield Message.Url, url, file
                    if previews_video:
                        file["media_id"] = f"{file['media_id']}p"
                    else:
                        continue

                url = file["display_url"]
                text.nameext_from_url(url, file)
                if file["extension"] == "webp" and "stp=dst-jpg" in url:
                    file["extension"] = "jpg"
                yield Message.Url, url, file

    def metadata(self):
        return ()

    def posts(self):
        return ()

    def _posts_expand(self, posts):
        if self.config("metadata"):
            for post in posts:
                yield from self.api.media(post["code"])
        else:
            for post in posts:
                if post.get("product_type") == "feed":
                    yield post
                else:
                    yield from self.api.media(post["code"])

    def finalize(self, status):
        if status and self._cursor:
            self.log.info("Use '-o cursor=%s' to continue downloading "
                          "from the current position", self._cursor)

    def request(self, url, **kwargs):
        response = Extractor.request(self, url, **kwargs)

        if response.history:

            url = response.url
            if "/accounts/login/" in url:
                page = "login"
            elif "/challenge/" in url:
                page = "challenge"
            elif 24 < len(url) < 28 and url[-1] == "/":
                page = "home"
            else:
                page = None

            if page is not None:
                raise self.exc.AbortExtraction(
                    f"HTTP redirect to {page} page ({url.partition('?')[0]})")

        www_claim = response.headers.get("x-ig-set-www-claim")
        if www_claim is not None:
            self.www_claim = www_claim

        if csrf_token := response.cookies.get("csrftoken"):
            self.csrf_token = csrf_token

        return response

    def login(self):
        if self.cookies_check(self.cookies_names):
            return

        username, password = self._get_auth_info()
        if username:
            return self.cookies_update(self.cache(
                self._login_impl, username, password,
                _exp=90*86400, _mem=False))

        self._logged_in = False

    def _login_impl(self, username, password):
        self.log.error("Login with username & password is no longer "
                       "supported. Use browser cookies instead.")
        return {}

    def _parse_post(self, post):
        owner = post.get("user") or {}
        if "items" in post:  # story or highlight
            items = post["items"]
            owner = owner or self._user or {}
            reel_type, _, reel_id = str(post["id"]).rpartition(":")
            if reel_type or post.get("reel_type") == "highlight_reel":
                post_url = f"{self.root}/stories/highlights/{reel_id}/"
                expires = None
                reel_type = "highlight"
            else:
                post_url = f"{self.root}/stories/{owner.get('username')}/"
                expires = post["seen"] + 86400
                reel_type = "story"
            data = {
                "user"   : owner,
                "expires": self.parse_timestamp(expires),
                "post_id": reel_id,
                "post_shortcode": shortcode_from_id(reel_id),
                "post_url": post_url,
                "type": reel_type,
            }
            if title := post.get("title"):
                data["highlight_title"] = title
            if not post.get("seen"):
                post["seen"] = post.get("latest_reel_media")
            if self._highlight_covers and (cover := post.get("cover_media")):
                if img := (cover.get("full_image_version") or
                           cover.get("cropped_image_version")):
                    img = img.copy()
                    img.setdefault("width", 0)
                    img.setdefault("height", 0)
                    items.insert(0, {
                        "pk"  : reel_id + "_cover",
                        "code": shortcode_from_id(reel_id),
                        "type": "cover",
                        "taken_at": post["seen"],
                        "image_versions2": {"candidates": (img,)}})

        else:  # regular image/video post
            data = {
                "post_id" : post["pk"],
                "post_shortcode": post["code"],
                "likes": post.get("like_count", 0),
                "liked": post.get("has_liked", False),
                "pinned": self._extract_pinned(post),
            }

            caption = post["caption"]
            data["description"] = caption["text"] if caption else ""

            if tags := self._find_tags(data["description"]):
                data["tags"] = sorted(set(tags))

            if location := post.get("location"):
                data["location_id"] = location_id = (
                    location.get("pk") or location.get("id"))
                data["location_name"] = name = (
                    location.get("name") or "")
                data["location_slug"] = slug = (
                    location.get("short_name") or name).replace(
                    " ", "-").lower()
                data["location_url"] = (
                    f"{self.root}/explore/locations/{location_id}/{slug}/")

            if coauthors := post.get("coauthor_producers"):
                data["coauthors"] = [
                    {"id"       : user.get("pk") or user.get("id"),
                     "username" : user.get("username"),
                     "full_name": user.get("full_name")}
                    for user in coauthors
                ]

            if items := post.get("carousel_media"):
                data["sidecar_media_id"] = data["post_id"]
                data["sidecar_shortcode"] = data["post_shortcode"]
            else:
                items = (post,)

        data["owner_id"] = owner.get("pk")
        data["username"] = owner.get("username")
        data["fullname"] = owner.get("full_name")
        data["post_date"] = data["date"] = self.parse_timestamp(
            post.get("taken_at") or post.get("created_at") or post.get("seen"))
        data["_files"] = files = []
        for num, item in enumerate(items, 1):

            try:
                image = item["image_versions2"]["candidates"][0]
            except Exception:
                self.log.warning("Missing media in post %s",
                                 data["post_shortcode"])
                continue

            if not self._static_video and \
                    (manifest := item.get("video_dash_manifest")) and \
                    (framerate := text.extr(manifest, 'frameRate="', '"')):
                num, _, den = framerate.partition("/")
                if num == den:
                    item.pop("video_versions", None)
                    item["original_width"] = image["width"]
                    item["original_height"] = image["height"]

            width_orig = item.get("original_width", 0)
            height_orig = item.get("original_height", 0)

            if video_versions := item.get("video_versions"):
                media = video = video_versions[-1]
                if (manifest := item.get("video_dash_manifest")) and \
                        self.videos_dash:
                    width = width_orig
                    height = height_orig
                else:
                    width = video.get("width") or width_orig
                    height = video.get("height") or height_orig

                if self._warn_video:
                    self._warn_video = False
                    pattern = text.re(
                        r"Chrome/\d{3,}\.\d+\.\d+\.\d+(?!\d* Mobile)")
                    if not pattern.search(self.session.headers["User-Agent"]):
                        self.log.warning("Potentially lowered video quality "
                                         "due to non-Chrome User-Agent")
            else:
                video = manifest = None
                media = image
                width = image["width"]
                height = image["height"]

                if self._warn_image < ((width * 1.1 < width_orig) +
                                       (height * 1.1 < height_orig)):
                    self.log.warning(
                        "%s: Available image resolutions lower than the "
                        "original (%sx%s < %sx%s). "
                        "Consider refreshing your cookies.",
                        data["post_shortcode"],
                        width, height, width_orig, height_orig)

            media = {
                "num"        : num,
                "date"       : self.parse_timestamp(item.get("taken_at") or
                                                    media.get("taken_at") or
                                                    post.get("taken_at")),
                "media_id"   : item["pk"],
                "shortcode"  : (item.get("code") or
                                shortcode_from_id(item["pk"])),
                "display_url": image["url"],
                "video_url"  : video["url"] if video else None,
                "width"          : width,
                "width_original" : width_orig,
                "height"         : height,
                "height_original": height_orig,
            }

            if manifest is not None:
                media["_ytdl_manifest_data"] = manifest
            if "owner" in item:
                media["owner"] = item["owner"]
            if "reshared_story_media_author" in item:
                media["author"] = item["reshared_story_media_author"]
            if "expiring_at" in item:
                media["expires"] = self.parse_timestamp(item["expiring_at"])
            if "subscription_media_visibility" in item:
                media["subscription"] = item["subscription_media_visibility"]
            elif item.get("audience") == "fan_club":
                media["subscription"] = True
            if "audience" in item:
                media["audience"] = item["audience"]

            self._extract_tagged_users(item, media)
            files.append(media)

            if stickers := item.get("story_music_stickers"):
                try:
                    if audio := self._extract_audio(item, media, stickers[0]):
                        audio["num"] = num
                        files.append(audio)
                except Exception as exc:
                    self.log.traceback(exc)

        if metadata := post.get("music_metadata"):
            try:
                if audio := self._extract_audio(
                        post, data, metadata.get("music_info")):
                    num += 1
                    audio["num"] = num
                    files.append(audio)
            except Exception as exc:
                self.log.traceback(exc)

        if clips := post.get("clips_metadata"):
            try:
                if audio := self._extract_audio(post, data, clips):
                    num += 1
                    audio["num"] = num
                    files.append(audio)
            except Exception as exc:
                self.log.traceback(exc)

        if "subscription_media_visibility" in post:
            data["subscription"] = post["subscription_media_visibility"]
        if "type" not in data:
            if len(files) == 1 and files[0]["video_url"]:
                data["type"] = "reel"
                data["post_url"] = f"{self.root}/reel/{post['code']}/"
            else:
                data["type"] = "post"
                data["post_url"] = f"{self.root}/p/{post['code']}/"

        return data

    def _extract_tagged_users(self, src, dest):
        dest["tagged_users"] = tagged_users = []

        if edges := src.get("edge_media_to_tagged_user"):
            for edge in edges["edges"]:
                user = edge["node"]["user"]
                tagged_users.append({"id"       : user["id"],
                                     "username" : user["username"],
                                     "full_name": user["full_name"]})

        if usertags := src.get("usertags"):
            for tag in usertags["in"]:
                user = tag["user"]
                tagged_users.append({"id"       : user["pk"],
                                     "username" : user["username"],
                                     "full_name": user["full_name"]})

        if mentions := src.get("reel_mentions"):
            for mention in mentions:
                user = mention["user"]
                tagged_users.append({"id"       : user.get("pk"),
                                     "username" : user["username"],
                                     "full_name": user["full_name"]})

        if stickers := src.get("story_bloks_stickers"):
            for sticker in stickers:
                try:
                    user = (sticker["bloks_sticker"]
                            ["sticker_data"]["ig_mention"])
                    tagged_users.append({"id"       : user.get("account_id"),
                                         "username" : user.get("username"),
                                         "full_name": user.get("full_name")})
                except Exception:
                    pass

    def _is_reel(self, post):
        product_type = post.get("product_type") or post.get(
            "media_product_type")
        return (
            product_type == "clips" or
            post.get("subtype_name_for_REST__") == "XDTClipsMedia" or
            "clips_metadata" in post
        )

    def _extract_pinned(self, post):
        return (post.get("timeline_pinned_user_ids") or
                post.get("clips_tab_pinned_user_ids") or ())

    def _extract_audio(self, src, dest, info):
        if not info or not (audio := info.get("music_asset_info") or
                            info.get("original_sound_info")):
            return None
        cinfo = info.get("music_consumption_info") or audio

        dest["audio_title"] = title = audio.get("title") or audio.get(
            "original_audio_title")
        dest["audio_duration"] = duration = audio.get(
            "duration_in_ms", 0) / 1000
        dest["audio_user"] = user = audio.get(
            "ig_artist") or cinfo.get("ig_artist")

        if parts := audio.get("audio_parts"):
            artist = [a for p in parts if (a := p.get("display_artist"))]
            timestamps = [p.get("parent_start_time_in_ms") for p in parts]
        else:
            artist = audio.get("display_artist") or cinfo.get("display_artist")
            timestamps = audio.get("highlight_start_times_in_ms")
        dest["audio_artist"] = artist
        dest["audio_timestamps"] = timestamps

        if not (url := audio.get("progressive_download_url")):
            return None
        audio_id = audio.get("id") or audio.get("audio_asset_id") or 0

        file = {
            "date"       : self.parse_timestamp(src.get("taken_at")),
            "media_id"   : audio_id,
            "shortcode"  : shortcode_from_id(audio_id),
            "display_url": audio.get("cover_artwork_uri"),
            "audio_url"  : url,
            "width"           : 0,
            "width_original"  : 0,
            "height"          : 0,
            "height_original" : 0,
            "audio_user"      : user,
            "audio_title"     : title,
            "audio_artist"    : artist,
            "audio_duration"  : duration,
            "audio_timestamps": timestamps,
        }

        if manifest := audio.get("dash_manifest"):
            file["_ytdl_manifest_data"] = manifest
        return file

    def _init_cursor(self):
        cursor = self.config("cursor", True)
        if cursor is True:
            cursor = None
        elif not cursor:
            cursor = None
            self._update_cursor = util.identity
        return cursor

    def _update_cursor(self, cursor):
        if cursor:
            self.log.debug("Cursor: %s", cursor)
        self._cursor = cursor
        return cursor

    def _assign_user(self, user):
        self._user = user

        for key, old in (
                ("count_media"     , "edge_owner_to_timeline_media"),
                ("count_video"     , "edge_felix_video_timeline"),
                ("count_saved"     , "edge_saved_media"),
                ("count_mutual"    , "edge_mutual_followed_by"),
                ("count_follow"    , "edge_follow"),
                ("count_followed"  , "edge_followed_by"),
                ("count_collection", "edge_media_collections")):
            try:
                user[key] = user.pop(old)["count"]
            except Exception:
                user[key] = 0

        return user


class InstagramPostExtractor(InstagramExtractor):
    """Extractor for an Instagram post"""
    subcategory = "post"
    pattern = (r"(?:https?://)?(?:www\.)?instagram\.com"
               r"/(?:share()(?:/(?:p|tv|reels?()))?"
               r"|(?:[^/?#]+/)?(?:p|tv|reels?()))"
               r"/([^/?#]+)")
    example = "https://www.instagram.com/p/abcdefg/"

    def __init__(self, match):
        if match[2] is not None or match[3] is not None:
            self.subcategory = "reel"
        InstagramExtractor.__init__(self, match)

    def posts(self):
        share, _, _, shortcode = self.groups
        if share is not None:
            url = text.ensure_http_scheme(self.url)
            headers = {
                "Sec-Fetch-Dest": "empty",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "same-origin",
            }
            location = self.request_location(url, headers=headers)
            shortcode = location.split("/")[-2]
        return self.api.media(shortcode)


class InstagramUserExtractor(Dispatch, InstagramExtractor):
    """Extractor for an Instagram user profile"""
    pattern = USER_PATTERN + r"/?(?:$|[?#])"
    example = "https://www.instagram.com/USER/"

    def items(self):
        base = f"{self.root}/{self.item}/"
        stories = f"{self.root}/stories/{self.item}/"
        return self._dispatch_extractors((
            (InstagramInfoExtractor      , base + "info/"),
            (InstagramAvatarExtractor    , base + "avatar/"),
            (InstagramStoriesExtractor   , stories),
            (InstagramHighlightsExtractor, base + "highlights/"),
            (InstagramHighlightsCoversExtractor, base + "highlights/covers/"),
            (InstagramPostsExtractor     , base + "posts/"),
            (InstagramPhotosExtractor    , base + "photos/"),
            (InstagramReelsExtractor     , base + "reels/"),
            (InstagramTaggedExtractor    , base + "tagged/"),
            (InstagramRepostsExtractor   , base + "reposts/"),
        ), ("posts",))


class InstagramPostsExtractor(InstagramExtractor):
    """Extractor for an Instagram user's posts"""
    subcategory = "posts"
    pattern = USER_PATTERN + r"/posts"
    example = "https://www.instagram.com/USER/posts/"

    def posts(self):
        return self.api.user_feed(self.item)

    def _extract_pinned(self, post):
        try:
            return post["timeline_pinned_user_ids"]
        except KeyError:
            return ()


class InstagramPhotosExtractor(InstagramExtractor):
    """Extractor for an Instagram user's photos"""
    subcategory = "photos"
    pattern = USER_PATTERN + r"/photos"
    example = "https://www.instagram.com/USER/photos/"

    def posts(self):
        for post in self.api.user_feed(self.item):
            if not self._is_reel(post):
                yield post


class InstagramReelsExtractor(InstagramExtractor):
    """Extractor for an Instagram user's reels"""
    subcategory = "reels"
    pattern = USER_PATTERN + r"/reels"
    example = "https://www.instagram.com/USER/reels/"

    def posts(self):
        for reel in self.api.user_reels(self.item):
            yield from self.api.media(reel["media"]["code"])

    def _extract_pinned(self, post):
        try:
            return post["clips_tab_pinned_user_ids"]
        except KeyError:
            return ()


class InstagramTaggedExtractor(InstagramExtractor):
    """Extractor for an Instagram user's tagged posts"""
    subcategory = "tagged"
    pattern = USER_PATTERN + r"/tagged"
    example = "https://www.instagram.com/USER/tagged/"

    def metadata(self):
        user = self.api.user(self.item)
        return {
            "tagged_owner_id" : user["id"],
            "tagged_username" : user["username"],
            "tagged_full_name": user.get("full_name"),
        }

    def posts(self):
        return self._posts_expand(self.api.user_tagged(self.item))


class InstagramRepostsExtractor(InstagramExtractor):
    """Extractor for an Instagram user's reposts"""
    subcategory = "reposts"
    pattern = USER_PATTERN + r"/reposts"
    example = "https://www.instagram.com/USER/reposts/"

    def posts(self):
        return self._posts_expand(self.api.user_reposts(self.item))


class InstagramSavedExtractor(InstagramExtractor):
    """Extractor for an Instagram user's saved media"""
    subcategory = "saved"
    pattern = USER_PATTERN + r"/saved(?:/all-posts)?/?$"
    example = "https://www.instagram.com/USER/saved/"

    def posts(self):
        return self.api.user_saved()


class InstagramCollectionExtractor(InstagramExtractor):
    """Extractor for Instagram collection"""
    subcategory = "collection"
    pattern = USER_PATTERN + r"/saved/([^/?#]+)/([^/?#]+)"
    example = "https://www.instagram.com/USER/saved/COLLECTION/12345"

    def __init__(self, match):
        InstagramExtractor.__init__(self, match)
        self.user, self.collection_name, self.collection_id = match.groups()

    def metadata(self):
        return {
            "collection_id"  : self.collection_id,
            "collection_name": text.unescape(self.collection_name),
        }

    def posts(self):
        return self.api.user_collection(self.collection_id)


class InstagramStoriesTrayExtractor(InstagramExtractor):
    """Extractor for your Instagram account's stories tray"""
    subcategory = "stories-tray"
    pattern = BASE_PATTERN + r"/stories/me/?$()"
    example = "https://www.instagram.com/stories/me/"

    def items(self):
        base = self.root + "/stories/id:"
        for story in self.api.reels_tray():
            story["date"] = self.parse_timestamp(story["latest_reel_media"])
            story["_extractor"] = InstagramStoriesExtractor
            yield Message.Queue, f"{base}{story['id']}/", story


class InstagramStoriesExtractor(InstagramExtractor):
    """Extractor for Instagram stories"""
    subcategory = "stories"
    pattern = (r"(?:https?://)?(?:www\.)?instagram\.com"
               r"/s(?:tories/(?:highlights/(\d+)|([^/?#]+)(?:/(\d+))?)"
               r"|/(aGlnaGxpZ2h0[^/?#]+)(?:\?story_media_id=(\d+))?)")
    example = "https://www.instagram.com/stories/USER/"

    def __init__(self, match):
        h1, self.user, m1, h2, m2 = match.groups()

        if self.user:
            self.highlight_id = None
        else:
            self.subcategory = InstagramHighlightsExtractor.subcategory
            self.highlight_id = "highlight:" + h1 if h1 else util.b64decode(h2)

        self.media_id = m1 or m2
        InstagramExtractor.__init__(self, match)

    def posts(self):
        reel_id = self.highlight_id or self.api.user(self.user)["id"]
        reels = list(self.api.reels_media((reel_id,)))

        if not reels:
            return ()

        if self.media_id:
            reel = reels[0]
            for item in reel["items"]:
                if item["pk"] == self.media_id:
                    reel["items"] = (item,)
                    break
            else:
                raise self.exc.NotFoundError("story")

        elif self.config("split"):
            reel = reels[0]
            reels = []
            for item in reel["items"]:
                item.pop("user", None)
                copy = reel.copy()
                copy.update(item)
                copy["items"] = (item,)
                reels.append(copy)

        return reels


class InstagramHighlightsCoversExtractor(InstagramExtractor):
    """Extractor for an Instagram user's story highlight covers"""
    subcategory = "highlights-covers"
    pattern = USER_PATTERN + r"/(?:highlights/)?covers"
    example = "https://www.instagram.com/USER/highlights/covers/"

    def posts(self):
        self._highlight_covers = True
        tray = self.api.highlights_tray(self.item)
        for hl in tray:
            hl["items"] = []
        return tray


class InstagramHighlightsExtractor(InstagramExtractor):
    """Extractor for an Instagram user's story highlights"""
    subcategory = "highlights"
    pattern = USER_PATTERN + r"/highlights"
    example = "https://www.instagram.com/USER/highlights/"

    def posts(self):
        reel_ids = [hl["id"] for hl in self.api.highlights_tray(self.item)]

        if order := self.config("order-posts"):
            if order in {"desc", "reverse"}:
                reel_ids.reverse()
            elif order in {"id", "id_asc"}:
                reel_ids.sort(key=lambda r: int(r[10:]))
            elif order == "id_desc":
                reel_ids.sort(key=lambda r: int(r[10:]), reverse=True)
            elif order != "asc":
                self.log.warning("Unknown posts order '%s'", order)

        chunk_size = 5
        for offset in range(0, len(reel_ids), chunk_size):
            yield from self.api.reels_media(
                reel_ids[offset : offset+chunk_size])


class InstagramFollowersExtractor(InstagramExtractor):
    """Extractor for an Instagram user's followers"""
    subcategory = "followers"
    pattern = USER_PATTERN + r"/followers"
    example = "https://www.instagram.com/USER/followers/"

    def items(self):
        uid = self.api.user(self.item)["id"]
        for user in self.api.user_followers(uid):
            user["_extractor"] = InstagramUserExtractor
            url = f"{self.root}/{user['username']}"
            yield Message.Queue, url, user


class InstagramFollowingExtractor(InstagramExtractor):
    """Extractor for an Instagram user's followed users"""
    subcategory = "following"
    pattern = USER_PATTERN + r"/following"
    example = "https://www.instagram.com/USER/following/"

    def items(self):
        uid = self.api.user(self.item)["id"]
        for user in self.api.user_following(uid):
            user["_extractor"] = InstagramUserExtractor
            url = f"{self.root}/{user['username']}"
            yield Message.Queue, url, user


class InstagramTagExtractor(InstagramExtractor):
    """Extractor for Instagram tags"""
    subcategory = "tag"
    directory_fmt = ("{category}", "{subcategory}", "{tag}")
    pattern = BASE_PATTERN + r"/explore/tags/([^/?#]+)"
    example = "https://www.instagram.com/explore/tags/TAG/"

    def metadata(self):
        return {"tag": text.unquote(self.item)}

    def posts(self):
        return self.api.tags_media(self.item)


class InstagramInfoExtractor(InstagramExtractor):
    """Extractor for an Instagram user's profile data"""
    subcategory = "info"
    pattern = USER_PATTERN + r"/info"
    example = "https://www.instagram.com/USER/info/"

    def items(self):
        user = self.api.user(self.item, check_private=False)
        return iter(((Message.Directory, "", user.copy()),))


class InstagramAvatarExtractor(InstagramExtractor):
    """Extractor for an Instagram user's avatar"""
    subcategory = "avatar"
    pattern = USER_PATTERN + r"/avatar"
    example = "https://www.instagram.com/USER/avatar/"

    def posts(self):
        user = self.api.user(self.item, check_private=False)
        avatar = (user.get("hd_profile_pic_url_info") or
                  user["hd_profile_pic_versions"][-1])
        avatar.setdefault("width", 0)
        avatar.setdefault("height", 0)

        if pk := user.get("profile_pic_id"):
            pk = pk.partition("_")[0]
            code = shortcode_from_id(pk)
        elif pk := text.rextr(avatar["url"], "/", "_n."):
            code = pk
        else:
            pk = code = "avatar:" + str(user["pk"])

        return ({
            "pk"        : pk,
            "code"      : code,
            "user"      : user,
            "caption"   : None,
            "like_count": 0,
            "image_versions2": {"candidates": (avatar,)},
        },)


class InstagramAPI():

    def __init__(self, extractor):
        self.extractor = extractor
        self.exc = extractor.exc

        _cache = self.extractor.config("user-cache", True)
        if not _cache or _cache == "memory":
            self._user_cache_mem = True
            self._user_cache_exp = 0
        else:
            self._user_cache_mem = False
            self._user_cache_exp = (text.parse_int(_cache.partition(":")[2])
                                    if _cache.__class__ is str else 0)

    def highlights_tray(self, handle):
        variables = {"user_id": str(self.user(handle)["id"])}

        result = self._call_graphql(
            "PolarisProfileStoryHighlightsTrayContentQuery", variables)
        return [edge["node"] for edge in result["highlights"]["edges"]]

    def reels_media(self, reel_ids):
        variables = {
            "initial_reel_id": reel_ids[0],
            "reel_ids"       : reel_ids,
            "first": 3,
            "last" : 2,
        }

        return self._pagination_graphql(
            "PolarisStoriesV3ReelPageGalleryQuery", variables,
            "xdt_api__v1__feed__reels_media__connection")

    def reels_tray(self):
        variables = {
            "data": {
                "is_following_feed": False,
                "reason": "web_home",
            },
            "suggestedUsersData": {
                "max_id": "",
                "max_number_to_display": 0,
                "module": "stories_tray",
                "paginate": False,
            },
        }
        return self._call_graphql(
            "PolarisStoriesV3TrayContainerQuery", variables,
        )["xdt_api__v1__feed__reels_tray"]["tray"]

    def media(self, shortcode):
        if len(shortcode) > 28:
            shortcode = shortcode[:-28]
        endpoint = f"/v1/media/{id_from_shortcode(shortcode)}/info/"
        return self._pagination(endpoint)

    def tags_media(self, tag):
        for section in self.tags_sections(tag):
            for media in section["layout_content"]["medias"]:
                yield media["media"]

    def tags_sections(self, tag):
        endpoint = f"/v1/tags/{tag}/sections/"
        data = {
            "include_persistent": "0",
            "max_id" : None,
            "page"   : None,
            "surface": "grid",
            "tab"    : "recent",
        }
        return self._pagination_sections(endpoint, data)

    def user_by_id(self, user_id):
        return self.extractor.cache(
            self._user_by_id_impl, user_id,
            _exp=self._user_cache_exp, _mem=self._user_cache_mem)

    def _user_by_id_impl(self, user_id):
        variables = {
            "enable_integrity_filters": True,
            "id"                      : user_id,
        }

        try:
            return self._call_graphql(
                "PolarisProfilePageContentQuery", variables, notfound="user",
            )["user"]
        except self.exc.ControlException:
            raise
        except Exception as exc:
            self.extractor.log.traceback(exc)
            raise self.exc.NotFoundError("user")

    def user_by_web(self, username):
        return self.extractor.cache(
            self._user_by_web_impl, username,
            _exp=self._user_cache_exp, _mem=self._user_cache_mem)

    def _user_by_web_impl(self, username):
        try:
            page = self.extractor.cache(self._webpage, "/" + username)
            if user_id := text.extr(page, '"profile_id":"', '"'):
                username = text.extr(page, '"params":{"username":"', '"')
                return {"id": user_id, "username": username}
        except self.exc.ControlException:
            raise
        except Exception as exc:
            self.extractor.log.traceback(exc)
        self.extractor.log.debug("Server response:\n%s", page)
        raise self.exc.NotFoundError("user")

    def user(self, handle, check_private=True):
        if handle.startswith("id:"):
            user_id = handle[3:]
        else:
            user = self.user_by_web(handle)
            user_id = self.extractor._assign_user(user)["id"]
        user = self.user_by_id(user_id)

        if check_private and user.get("is_private"):
            fs = user.get("friendship_status")
            if fs and not fs.get("following", True) or \
                    not user.get("followed_by_viewer", True):
                name = user["username"]
                s = "" if name.endswith("s") else "s"
                self.extractor.log.warning("%s'%s posts are private", name, s)

        return self.extractor._assign_user(user)

    def user_collection(self, collection_id):
        endpoint = f"/v1/feed/collection/{collection_id}/posts/"
        params = {"count": 50}
        return self._pagination(endpoint, params, media=True)

    def user_feed(self, handle):
        variables = {
            "after"   : None,
            "before"  : None,
            "data"    : {
                "count": 12,
                "include_reel_media_seen_timestamp": True,
                "include_relationship_info": True,
                "latest_besties_reel_media": True,
                "latest_reel_media": True,
            },
            "first"   : 12,
            "include_multi_captions": True,
            "last"    : None,
            "username": self.user(handle)["username"],
            "__relay_internal__pv__"
            "PolarisSEOIsCrawlerrelayprovider": False,
        }

        return self._pagination_graphql(
            "PolarisProfilePostsTabContentQuery_connection", variables,
            "xdt_api__v1__feed__user_timeline_graphql_connection")

    def user_reels(self, handle):
        user_id = str(self.user(handle)["id"])

        variables = {
            "after": None,
            "data" : {
                "include_feed_video": True,
                "page_size": 12,
                "target_user_id": user_id,
            },
            "first": 12,
            "id": user_id,
        }

        return self._pagination_graphql(
            "PolarisProfileReelsTabContentQuery_connection", variables,
            "fetch__XDTUserDict", "/reels")

    def user_reposts(self, handle):
        variables = {
            "max_id": None,
            "id"    : str(self.user(handle)["id"]),
        }

        return self._pagination_graphql(
            "PolarisProfileRepostsTabContentRefetchQuery", variables,
            "fetch__XDTUserDict", "/reposts")

    def user_tagged(self, handle):
        variables = {
            "after"  : None,
            "before" : None,
            "count"  : 12,
            "first"  : 12,
            "last"   : None,
            "user_id": str(self.user(handle)["id"]),
        }

        return self._pagination_graphql(
            "PolarisProfileTaggedTabContentQuery_connection", variables,
            "xdt_api__v1__usertags__user_id__feed_connection", "/tagged")

    def user_followers(self, user_id):
        endpoint = f"/v1/friendships/{user_id}/followers/"
        params = {"count": 12}
        return self._pagination_following(endpoint, params)

    def user_following(self, user_id):
        endpoint = f"/v1/friendships/{user_id}/following/"
        params = {"count": 12}
        return self._pagination_following(endpoint, params)

    def user_saved(self):
        endpoint = "/v1/feed/saved/posts/"
        params = {"count": 50}
        return self._pagination(endpoint, params, media=True)

    def _extract_fb_tokens(self, path):
        extr = self.extractor
        lsd = extr.config("lsd")
        dtsg = extr.config("fb-dtsg")
        if lsd and dtsg:
            extr.log.debug("Using 'config' GraphQL tokens")
            return lsd, dtsg

        extr.log.debug("Extracting GraphQL tokens")
        page = extr.cache(self._webpage, path)
        pos = page.find(' id="__eqmc"')
        eqmc = util.json_loads(
            page[page.find(">", pos)+1:page.find("</script>", pos)])
        if not lsd:
            lsd = (eqmc.get("l") or
                   text.extr(page, '"lsd":"', '"') or
                   text.extr(page, '"LSD",[],{"token":"', '"'))
        if not dtsg:
            dtsg = (eqmc.get("f") or
                    text.extr(page, '"dtsg":{"token":"', '"'))
        extr.log.debug("Found 'lsd=%s' & 'fb_dtsg=%s'", lsd, dtsg)
        return lsd, dtsg

    def _extract_opname_info(self, opname, path):
        extr = self.extractor
        extr.log.debug("Collecting GraphQL parameters")

        opname_map = {}
        params_map = {}
        base = "https://static.cdninstagram.com/rsrc.php/"
        opnames = "|".join(QUERIES)
        docids_pattern = text.re(
            rf'__d\("({opnames})_instagramRelayOperation",\[\],'
            rf'\(function\([^)]+\).+?\bexports="([^"]+)')
        params_pattern = text.re(
            rf'__d\("({opnames})(?:\.graphql|\$Parameters)",\[([^\]]+)\]')

        for href in util.unique(text.extract_iter(
                extr.cache(self._webpage, path), 'href="' + base, '"')):
            if not href.endswith(".js"):
                continue
            url = base + text.unescape(href)
            script = extr.request(url, interval=False).text
            for name, docid in docids_pattern.findall(script):
                opname_map[name] = docid
            for name, params in params_pattern.findall(script):
                if not params_map.get(name):
                    params_map[name] = [
                        param[1:-15] for param in params.split(",")
                        if param.endswith('.relayprovider"')]

        for name, docid in opname_map.items():
            opname_map[name] = info = (docid, params_map.get(name))
            extr.cache_update(self._extract_opname_info, name, info,
                              _exp=86400, _mem=False)

        return opname_map[opname]

    def _webpage(self, path):
        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,"
                      "image/avif,image/webp,image/apng,*/*;q=0.8,"
                      "application/signed-exchange;v=b3;q=0.7",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-User": "?1",
            "Sec-Fetch-Dest": "document",
        }
        extr = self.extractor
        return extr.request(f"{extr.root}{path}/", headers=headers,
                            interval=False).text

    def _prepare_graphql(self, opname, variables, fieldname=None, path=""):
        extr = self.extractor
        root = extr.root

        if extr._user:
            path = f"/{extr._user['username']}{path}"
        elif path:
            path = "/instagram" + path

        fb_lsd, fb_dtsg = self._extract_fb_tokens(path)
        docid, params = extr.cache(self._extract_opname_info, opname, path,
                                   _exp=86400, _mem=False)
        if params:
            for param in params:
                name = f"__relay_internal__pv__{param}relayprovider"
                value = (param != "PolarisSEOIsCrawler")
                variables.setdefault(name, value)

        headers = {
            "Accept"            : "*/*",
            "Content-Type"      : "application/x-www-form-urlencoded",
            "X-FB-Friendly-Name": opname,
            "X-CSRFToken"       : extr.csrf_token,
            "X-IG-App-ID"       : "936619743392459",
            "X-IG-Max-Touch-Points": "0",
            "X-Root-Field-Name" : fieldname,
            "X-FB-LSD"          : fb_lsd,
            "X-ASBD-ID"         : "359341",
            "Origin"            : root,
            "Alt-Used"          : root[8:],
            "Connection"        : "keep-alive",
            "Referer"           : f"{root}{path}/",
            "Cookie"            : None,
            "Sec-Fetch-Dest"    : "empty",
            "Sec-Fetch-Mode"    : "cors",
            "Sec-Fetch-Site"    : "same-site",
        }
        body = {
            "av"    : "17841415137994167",
            "__d"   : "www",
            "__user": "0",
            "__a"   : "1",
            "__req" : "0",
            "__hs"  : "20731.HYP%3Ainstagram_web_pkg.2.1...0",
            "dpr"   : "1",
            "__ccg" : "EXCELLENT",
            "__rev" : "1049285836",
            "__hsi" : "7693193318680449885",
            "__comet_req": "7",
            "fb_dtsg"  : fb_dtsg,
            "jazoest"  : "26461",
            "lsd"      : fb_lsd,
            "fb_api_caller_class": "RelayModern",
            "fb_api_req_friendly_name": opname,
            "server_timestamps": "true",
            "variables": util.json_dumps(variables),
            "doc_id"   : docid or QUERIES[opname],
        }

        return headers, body

    def _load_graphql(self, result, fieldname=None):
        if (pos := result.find("{")) > 0:
            # remove 'for (;;);' guard
            result = result[pos:]

        try:
            data = util.json_loads(result)
            return (data["data"] if fieldname is None else
                    data["data"][fieldname])
        except ValueError as exc:
            msg = f"Failed to load API data ({exc.__class__.__name__}: {exc})"
        except Exception:
            if err := data.get("errors"):
                msg = f'"{err[0]["message"]}"'
            elif err := data.get("errorDescription"):
                msg = f'"{data.get("errorSummary")} - {err}"'
            else:
                msg = "Failed to load API data"

        self.extractor.log.debug("Server response:\n%s", result)
        raise self.exc.AbortExtraction(msg)

    def _call(self, endpoint, **kwargs):
        extr = self.extractor

        if endpoint[0] == "/":
            url = "https://www.instagram.com/api" + endpoint
        else:
            url = endpoint
        kwargs["headers"] = {
            "Accept"          : "*/*",
            "X-CSRFToken"     : extr.csrf_token,
            "X-IG-App-ID"     : "936619743392459",
            "X-ASBD-ID"       : "359341",
            "X-IG-WWW-Claim"  : extr.www_claim,
            "X-IG-Max-Touch-Points": "0",
            "X-Requested-With": "XMLHttpRequest",
        }
        return extr.request_json(url, **kwargs)

    def _call_graphql(self, opname, variables, **kwargs):
        extr = self.extractor

        kwargs["method"] = "POST"
        kwargs["headers"], body = self._prepare_graphql(opname, variables)
        kwargs["data"] = body

        extr.log.debug("%s (%s)", opname, body["doc_id"])
        extr.log.debug(body["variables"])
        result = extr.request(extr.root + "/api/graphql", **kwargs).text
        return self._load_graphql(result)

    def _pagination(self, endpoint, params=None, media=False):
        if params is None:
            params = {}
        extr = self.extractor
        params["max_id"] = extr._init_cursor()

        while True:
            data = self._call(endpoint, params=params)

            if media:
                for item in data["items"]:
                    yield item["media"]
            else:
                yield from data["items"]

            if not data.get("more_available"):
                return extr._update_cursor(None)
            params["max_id"] = extr._update_cursor(data["next_max_id"])

    def _pagination_sections(self, endpoint, params):
        extr = self.extractor
        params["max_id"] = extr._init_cursor()

        while True:
            info = self._call(endpoint, method="POST", data=params)

            yield from info["sections"]

            if not info.get("more_available"):
                return extr._update_cursor(None)
            params["page"] = info["next_page"]
            params["max_id"] = extr._update_cursor(info["next_max_id"])

    def _pagination_following(self, endpoint, params):
        extr = self.extractor
        params["max_id"] = text.parse_int(extr._init_cursor())

        while True:
            data = self._call(endpoint, params=params)

            yield from data["users"]

            next_max_id = data.get("next_max_id")
            if not next_max_id:
                return extr._update_cursor(None)
            params["max_id"] = extr._update_cursor(next_max_id)

    def _pagination_graphql(self, opname, variables, fieldname, path=""):
        extr = self.extractor
        url = extr.root + "/graphql/query"

        if "max_id" in variables:
            variables["max_id"] = extr._init_cursor()
        else:
            variables["after"] = extr._init_cursor()
        headers, body = self._prepare_graphql(
            opname, variables, fieldname, path)

        while True:
            extr.log.debug("%s (%s)", opname, body["doc_id"])
            extr.log.debug(body["variables"])
            headers["X-CSRFToken"] = extr.csrf_token
            result = extr.request(
                url, method="POST", headers=headers, data=body).text
            data = self._load_graphql(result, fieldname)

            if "max_id" in variables:
                data = data["user_reposts_timeline"]

                for item in data["repost_grid_items"]:
                    yield item["media"]

                if not data.get("repost_more_available"):
                    break
                variables["max_id"] = extr._update_cursor(
                    data["repost_next_max_id"])
            else:
                if "edges" not in data:
                    for value in data.values():
                        if value.__class__ is dict and "edges" in value:
                            data = value
                            break
                    else:
                        break

                for edge in data["edges"]:
                    yield edge["node"]

                info = data.get("page_info")
                if not info or not info.get("has_next_page"):
                    break
                variables["after"] = extr._update_cursor(info["end_cursor"])

            body["variables"] = util.json_dumps(variables)


def id_from_shortcode(shortcode):
    return util.bdecode(shortcode, _ALPHABET)


def shortcode_from_id(post_id):
    return util.bencode(int(post_id), _ALPHABET)


_ALPHABET = ("ABCDEFGHIJKLMNOPQRSTUVWXYZ"
             "abcdefghijklmnopqrstuvwxyz"
             "0123456789-_")
